package com.lec.ch05_member;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch05MemberApplicationTests {

	@Test
	void contextLoads() {
	}

}
