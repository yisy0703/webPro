package com.lec.ch05_member;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch05MemberApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch05MemberApplication.class, args);
	}

}
