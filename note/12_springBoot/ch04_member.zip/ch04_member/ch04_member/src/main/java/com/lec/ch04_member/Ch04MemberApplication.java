package com.lec.ch04_member;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch04MemberApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch04MemberApplication.class, args);
	}

}
