package com.lec.ch04_member;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch04MemberApplicationTests {

	@Test
	void contextLoads() {
	}

}
