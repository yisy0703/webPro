package com.lec.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch03HelloGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch03HelloGradleApplication.class, args);
	}

}
