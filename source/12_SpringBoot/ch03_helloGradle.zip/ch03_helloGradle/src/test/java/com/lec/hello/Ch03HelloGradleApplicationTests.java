package com.lec.hello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch03HelloGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
